COURSE - CPSC 6430 - MACHINE LEARNING IMPLEMENTATION AND EVALUATION

PROFESSOR - DR. LARRY F HODGES

STUDENT - ADITHYA SURESH, C18590622

PROJECT 0:

1) The project requires a datafile to start with and when fed as input,
it splits the columns and rows based on features and data (delimiter is a tab).

2) Then an empty list is created for storing the data and the code asks for horizontal
and vertical axes feature codes from the user.

3) The data is categorized into the flower type and respective color and marker are associated

4) Then based on the input features along horizontal and vertical axes, the axes labels are
plotted along with the legend and title.

5) Then the code asks whether the user wants do another plot, if pressed 'y' (yes), the above procedure is
repeated, if pressed 'n' no then the code is terminated. This is done by setting flag